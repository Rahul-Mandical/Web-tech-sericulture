<html lang="en">
<head>
  <title>Sericulture</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="js/jquery-3.4.1.min.js"></script>
 
  <script src="js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-md  bg-navv navbar-dark justify-content-between fixed-top">
  <a class="navbar-brand" href="#">Sericulture</a>
  
</nav>
    </body>
</html>
