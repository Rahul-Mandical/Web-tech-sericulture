<!DOCTYPE html>

<html lang="en">
    <head>
     <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/styles.css">
  <script src="js/jquery-3.4.1.min.js"></script>
 
  <script src="js/bootstrap.min.js"></script>
    </head>
<?php //include 'header.php'; ?>
<body>
 <div class="container-fluid" style="padding-top:300px;">
     <div class="my_cartimage">
         
     </div>
    </div>
</body>
</html>