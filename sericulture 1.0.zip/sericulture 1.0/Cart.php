<?php include'header1.php';
include "db.php";
    session_start();
if(isset($_SESSION['uid']))
{
    
    ?><div class="alert alert-success" style="padding-top:100px;">
    <strong>Welcome!</strong><?php?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php }
else
{
    echo '<div class="alert alert-danger" role="alert" style="padding-top:100px;" id="err">
		<strong>Hello!</strong> Please Login to checkout the products
			<a class="btn btn-danger" href="logincart.php?type=3" role="button">Login</a>
			
		
</div>';
}
?>
<html>

<body>
    <form method="post" action="">
        <div class="container">
            <table class="table table-bordered text-center container">
                <thead class="thead-color">
                    <tr>
                        <th scope="col">Product</th>
                        <th scope="col">Name</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">cost</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>

                    <?php
           $query="select c.cart_id,c.product_id,p.pname,p.photo,c.quantity,p.price from product as p,cart as c WHERE c.product_id=p.product_id and c.ordered=0";
          $result=mysqli_query($mysqli,$query);
           $value=1;
    if(isset($_POST['add']))
    {
        $value=$_POST['quant'];
        $value=$value+1;
        
        
    }
    if(isset($_POST['minus']))
    {
        $value=$_POST['quant'];
        if($value>0)
        {
        $value=$value-1;
        }
    }
     while ($row=mysqli_fetch_assoc($result)){
           echo "<tr>";?>
                    <td><img class="img-fluid img-thumbnail" src="<?php echo $row['photo']?>" alt="image" height="100" width="100"></td>
                    <?php echo "<td>".$row['pname']."</td>";
                    echo "<td>".$row['price']."</td>";
               echo "<td>"?><div class="form-group">
                        <div class="row align-center">

                            <div class="col-sm-4">
                                <span>
                                    <button type="submit" class="btn btn-primary" name="minus">-</button>
                                </span>
                            </div>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" value="<?php echo $value;?>" id="no" name="quant">
                            </div>
                            <div class="col-sm-4">
                                <span>
                                    <button type="submit" name="add" class="btn btn-primary">+
                                    </button>
                                </span>
                            </div>

                        </div>


                    </div><?php echo"</td>";
           echo "<td>"?>

                    <?php 
                $total1=$value*$row['price'];
                echo $total1;
echo "</td>";?>
                    <td><span><a class="btn btn-primary" href="add.php?pno=<?php echo $row['product_id'];?>&quant=<?php echo $_POST['quant'];?>&cost=<?php echo $total1;?>" role="button">update</a></span>
                        <span><a class="btn btn-danger" href="deletepro.php?cartid=<?php echo $row['cart_id'];?>" role="button">Delete</a></span></td>
                    <?php echo "</tr>";

     }
?>
                </tbody>
            </table>
        </div>
    </form>

    <form action="" method="post">
        <div class="container">
            <center>
                <a class="btn btn-success" href="clearcart.php?clear=1" role="button">Clear Cart</a>
                <?php 
                if(isset($_SESSION['uid']))
                {
                   echo '
                    <button type="button" class="btn btn-success" onclick="javascript:alert("please login");">Buy Now</button>';
                }
                else
                {
         echo'<button type="submit" class="btn btn-success" name="Buy">Buy Now</button>';
                }
             ?>
            </center>
        </div>
<?php
        if(isset($_POST['Buy']))
        {
           // $query1="update cart set ordered=1,cost='$total1'"
        }
        ?>
    </form>
</body>

</html>