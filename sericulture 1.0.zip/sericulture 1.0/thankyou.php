<?php include'header1.php'?>
<div class="container" style="padding-top:300px;">
    <h1 style="color:#67b360;">YOUR ORDER ARE CONFIRMED.THANK YOU VISIT AGAIN</h1>
</div>