<div class="container-fluid" style="padding-top:100px;">
	<ul class="nav nav-pills justify-content-left">
       <a class="nav-link btn-success active" href="#">STOCK</a>
       <a class="nav-link btn-success" href="orders.php">ORDERS</a>
   </ul>
    </div>